package com.example.mealprep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealprepApplication {

	public static void main(String[] args) {
		SpringApplication.run(MealprepApplication.class, args);
	}

}
